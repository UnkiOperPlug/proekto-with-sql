﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для adminudalenie.xaml
    /// </summary>
    public partial class adminudalenie : Window
    {
        Class1 class1 = new Class1();
        public adminudalenie()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            adminvivod g = new adminvivod();
            g.Show();
            this.Close();
        }

        private void x_Click(object sender, RoutedEventArgs e)
        {

        }


        private void udalit_Click(object sender, RoutedEventArgs e)
        {
            SqlDataAdapter adapter = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();

            var name1 = name.Text;
            

            string wlk = $"delete from shokolad where name = '{name1}' ";
            SqlCommand command2 = new SqlCommand(wlk, class1.getConnection());
            adapter.SelectCommand = command2;
            adapter.Fill(table1);

            MessageBox.Show("Вы успешно удалили");
        }

        private void name_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
