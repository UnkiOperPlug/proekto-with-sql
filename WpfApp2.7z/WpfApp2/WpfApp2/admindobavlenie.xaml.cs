﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для admindobavlenie.xaml
    /// </summary>
    public partial class admindobavlenie : Window
    {
        Class1 class1 = new Class1();
        public admindobavlenie()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            adminvivod ee = new adminvivod();
            ee.Show();
            this.Close();
        }

      

        private void zakrit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_2(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_3(object sender, TextChangedEventArgs e)
        {

        }

        private void add_Click(object sender, RoutedEventArgs e)
        {
            SqlDataAdapter adapter = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();

            var name1 = name.Text;
            var kolvo1 = kolichestvo.Text;
            var ediniciizmereniya1 = ediniciizmereniya.Text;
            var cena1 = cena.Text;

            string wlk = $"INSERT INTO [dbo].[shokolad] VALUES ('{name1}', '{kolvo1}', '{ediniciizmereniya1}', '{cena1}')";
            SqlCommand command2 = new SqlCommand(wlk, class1.getConnection());
            adapter.SelectCommand = command2;
            adapter.Fill(table1);

            MessageBox.Show("Вы успешно добавили");
        }
    }
}
